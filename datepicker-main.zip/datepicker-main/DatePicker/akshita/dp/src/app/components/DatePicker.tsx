import React, { useState } from 'react';
import RecurrenceOptions from './RecurrenceOptions';

// Component for selecting start and end dates
const DatePicker: React.FC = () => {
  const [recurrencePattern, setRecurrencePattern] = useState('daily');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  return (
    <div className="p-4 bg-white rounded-lg shadow-md">
      <h1>Date Picker</h1>
      <RecurrenceOptions 
        recurrencePattern={recurrencePattern} 
        setRecurrencePattern={setRecurrencePattern} 
      />
      <input 
        type="date" 
        value={startDate} 
        onChange={(e) => setStartDate(e.target.value)} 
        className="border border-gray-300 rounded-md p-2 mb-4 w-full"
      />
      <input 
        type="date" 
        value={endDate} 
        onChange={(e) => setEndDate(e.target.value)} 
        className="border border-gray-300 rounded-md p-2 mb-4 w-full"
      />
      <div>
        <h3>Preview:</h3>
        <p>Start Date: {startDate}</p>
        <p>End Date: {endDate}</p>
        <p>Recurrence: {recurrencePattern}</p>
      </div>
    </div>
  );
};

export default DatePicker;
