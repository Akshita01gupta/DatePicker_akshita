import React from 'react';


interface RecurrenceOptionsProps {
    recurrencePattern: string;
    setRecurrencePattern: (pattern: string) => void;
  }
  // Component for selecting recurrence options
  const RecurrenceOptions: React.FC<RecurrenceOptionsProps> = ({ recurrencePattern, setRecurrencePattern }) => {
    return (
      <div className="mb-4">
        <h3>Recurrence Options</h3>
        <select 
          value={recurrencePattern} 
          onChange={(e) => setRecurrencePattern(e.target.value)} 
          className="border border-gray-300 rounded-md p-2 mb-4 w-full"
        >
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
          <option value="monthly">Monthly</option>
          <option value="yearly">Yearly</option>
        </select>
      </div>
    );
  };
  
  export default RecurrenceOptions;
  